package com.example.consultation.myapplication;

/**
 * Created by user on 7/3/2017.
 */

public class ModelChat {
    public String getSendBy() {
        return sendBy;
    }

    public void setSendBy(String sendBy) {
        this.sendBy = sendBy;
    }

    String sendBy,messeges;



    public String getMesseges() {
        return messeges;
    }

    public void setMesseges(String messeges) {
        this.messeges = messeges;
    }
}
